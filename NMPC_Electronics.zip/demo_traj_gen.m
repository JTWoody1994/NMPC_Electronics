clear all
close all
clc
    Xstart=0;%轨迹起点
    Ystart=0;
roadmap_name = 'loop_road';  %选择路网: straight_road circle_road loop_road
 [trajref_params] =demo_set_trajref_params(roadmap_name);   %设置trajref参数
 trajref = demo_generate_pretrajref(trajref_params,roadmap_name,Xstart,Ystart);         %生成trajref
