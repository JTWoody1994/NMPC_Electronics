function [ind] = calc_target_index(x,y, cx,cy,n)
N =  length(cx);
Distance = zeros(N,1);
for i = 1:N
Distance(i) =  sqrt((cx(i)-x)^2 + (cy(i)-y)^2);
end
[~, location]= min(Distance);
ind = location;

 ind = ind+n;%预瞄10步10dt
end