function [J] = objectiveFunction(U, P, Q, R, N, dt, L,v_d,delta_d)
    X = P(1:3);
    xs = P(4:6);
    J = 0;

    % 计算目标函数值、梯度和海塞矩阵
    for k = 1:N
        v = U(2*k-1);
        delta = U(2*k);
        theta = X(3);
        X_next = X + dt * [v * cos(theta); v * sin(theta); v * tan(delta) / L];
        e = X_next - xs;
        %===========================================
        %******防止偏差数据溢出***********%这部分还是比较重要的，很容易溢出
        if e(3) <= -pi
        e(3) = e(3)+2*pi;
        end
        if e(3) >=pi
        e(3) = e(3) -2*pi;
        end
        %===========================================
        
        J = J + e' * Q * e + [v-v_d; delta-delta_d]' * R * [v-v_d; delta-delta_d];

    end

end

