function [v,delta,uu] = MPC_controller(ref_state,current_state,dt,Length,vd1,curvature,N,v_min,v_max, delta_min,delta_max,ulast)

Nx = 3;%状态量的个数
Nu = 2;%控制量的个数
Np = N;%预测步长
Nc = N;%控制步长
vd2=atan(Length * curvature);%  期望前轮转角
Q=1000*eye(Nx*Np,Nx*Np);  % 单位矩阵，Q和R为权重矩阵
R=1000*eye(Nu*Nc);         % Q反应对参考轨迹的跟踪能力，R为对控制量变化的约束

  %******防止偏差数据溢出***********%这部分还是比较重要的，很容易溢出


a=[1    0   -vd1*sin(ref_state(3))*dt;
    0    1   vd1*cos(ref_state(3))*dt;
    0    0   1;];
b=[cos(ref_state(3))*dt   0;
    sin(ref_state(3))*dt   0;
    tan(vd2)*dt/Length      vd1*dt/(Length * (cos(vd2)^2))];


A_cell=cell(2,2);
B_cell=cell(2,1);
A_cell{1,1}=a;
A_cell{1,2}=b;
A_cell{2,1}=zeros(Nu,Nx);
A_cell{2,2}=eye(Nu);
B_cell{1,1}=b;
B_cell{2,1}=eye(Nu);

A=cell2mat(A_cell);
B=cell2mat(B_cell);

C=[ 1 0 0 0 0;
    0 1 0 0 0;
    0 0 1 0 0];
%以上代码对应（4.10）中的参数
PHI_cell=cell(Np,1);
THETA_cell=cell(Np,Nc);
for j=1:1:Np
    PHI_cell{j,1}=C*A^j;
    for k=1:1:Nc
        if k<=j
            THETA_cell{j,k}=C*A^(j-k)*B;
        else
            THETA_cell{j,k}=zeros(Nx,Nu);
        end
    end
end
PHI=cell2mat(PHI_cell);%size(PHI)=[Nx*Np Nx+Nu]
THETA=cell2mat(THETA_cell);%size(THETA)=[Nx*Np Nu*Nc]

Row=0.01;
H_cell = cell(2,2);
H_cell{1,1}=THETA'*Q*THETA+R;
H_cell{1,2}=zeros(Nu*Nc,1);
H_cell{2,1}=zeros(1,Nu*Nc);
H_cell{2,2}=Row;
H=cell2mat(H_cell);
H=(H+H')/2;

kesi=current_state-ref_state(1:3);
  %******防止偏差数据溢出***********%这部分还是比较重要的，很容易溢出
    if kesi(3) <= -pi
        kesi(3) = kesi(3)+2*pi;
    end
    if kesi(3) >=pi
        kesi(3) = kesi(3) -2*pi;
    end
    
kesi(4)=ulast(1)-vd1;
kesi(5)=ulast(2)-vd2;

error = PHI*kesi;
f_cell = cell(1,2);
f_cell{1,1} = 2*(error'*Q*THETA);
f_cell{1,2} = 0;
f = cell2mat(f_cell);

A_t=zeros(Nc,Nc);%见falcone论文 P181
for p=1:1:Nc
    for q=1:1:Nc
        if q<=p
            A_t(p,q)=1;
        else
            A_t(p,q)=0;
        end
    end
end
A_I=kron(A_t,eye(Nu));%对应于falcone论文约束处理的矩阵A,求克罗内克积
Ut=kron(ones(Nc,1),ulast);

% 其他轨迹-sin轨迹
umin=[v_min;delta_min];
umax=[v_max;delta_max];
Umin=kron(ones(Nc,1),umin);
Umax=kron(ones(Nc,1),umax);

delta_umin = [ -3 ; -1];
delta_umax = [  3 ;  1];
delta_Umin = kron(ones(Nc,1),delta_umin);
delta_Umax = kron(ones(Nc,1),delta_umax);
lb = [delta_Umin; 0];%（求解方程）状态量下界
ub = [delta_Umax; Row];%（求解方程）状态量上界

A_cons_cell={A_I zeros(Nu*Nc, 1); -A_I zeros(Nu*Nc, 1)};
b_cons_cell={Umax-Ut;-Umin+Ut};
A_cons=cell2mat(A_cons_cell);%（求解方程）状态量不等式约束增益矩阵，转换为绝对值的取值范围
b_cons=cell2mat(b_cons_cell);%（求解方程）状态量不等式约束的取值
%==============================================================
% 开始求解过程
%==============================================================
options = optimset('Algorithm','interior-point-convex');
% options = optimoptions('quadprog','Display','iter','MaxIterations',100,'TolFun',1e-16);
[u_now, ~, ~]=quadprog(H, f, A_cons,b_cons,[], [],lb,ub,[],options);

% xstart=zeros(2*Nc+1,1);
% [u_now, ~, ~]=quadprog(H, f, A_cons,b_cons,[], [],lb,ub,xstart,options);

v = kesi(4)+u_now(1)+ vd1;      
delta=  kesi(5)+u_now(2)+ vd2;
uu=[u_now(3:end-1); u_now(end-2:end-1)]+kron(ones(Nc,1),[kesi(4)+ vd1;kesi(5)+ vd2]); % Shift control inputs

end