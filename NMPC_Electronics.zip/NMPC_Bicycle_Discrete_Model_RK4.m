function x_next = NMPC_Bicycle_Discrete_Model_RK4(x, u, dt, L)
    % 定义用于计算的中间变量
    f = @(x,u) [u(1) * cos(x(3));
                u(1) * sin(x(3));
                u(1) * tan(u(2)) / L];

    % 计算龙格库塔法的四个中间步长
    k1 = f(x, u);
    k2 = f(x + 0.5 * dt * k1, u);
    k3 = f(x + 0.5 * dt * k2, u);
    k4 = f(x + dt * k3, u);
    
    % 根据龙格库塔公式更新状态变量
    x_next = x + (dt / 6) * (k1 + 2*k2 + 2*k3 + k4);
    
    if x_next(3) <= -pi
        x_next(3) = x_next(3)+2*pi;
    end
    if x_next(3) >=pi
        x_next(3) = x_next(3) -2*pi;
    end
end
