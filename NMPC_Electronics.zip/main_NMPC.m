clear all
close all
clc

Xstart=0;%轨迹起点
Ystart=0;
roadmap_name = 'loop_road';  %选择路网: straight_road circle_road
[trajref_params] =demo_set_trajref_params(roadmap_name);   %设置trajref参数
trajref = demo_generate_pretrajref(trajref_params,roadmap_name,Xstart,Ystart);         %生成trajref

switch (roadmap_name)
   case 'loop_road'   
    % 车辆参数
     L = 2.886; % 轴距
    % 初始状态
    x0=[0.2;0;0];%小车初始朝向，向上是pi/2，向右是0，向下是-pi/2,向左是-pi
    % 控制输入界限
    v_min = -5.02;
    v_max = 5.02;
    v_desire = 5;
    delta_min = -pi/6;
    delta_max = pi/6;

    n=2; %往前预测未来n个时刻的车子位移及航向角位移;
    dt = 0.1;%控制间隔
    % 存储状态
    trajectory = zeros(3,3000);
    control_state = zeros(2,3000);
    car2obj_dist=zeros(10,3000);
    traj_reference = zeros(3,3000);
    totaltime=zeros(1,3000); 
       
     % =========提前画出赛道==============
    figure (1);
    roadmap_name = 'loop_road_out';  %选择路网: straight_road circle_road loop_road
    Xstart=-2.5;
    Ystart=5;
    [trajref_params_out] =demo_set_trajref_params(roadmap_name);   %设置trajref参数
    trajref_out = demo_generate_pretrajref(trajref_params_out,roadmap_name,Xstart,Ystart);         %生成trajref
    plot(trajref_out(1,:), trajref_out(2,:), 'k-', 'LineWidth', 1.5);
    hold on;
    
    roadmap_name = 'loop_road_in';  %选择路网: straight_road circle_road loop_road
    Xstart=2.5;
    Ystart=-5;
    [trajref_params_in] =demo_set_trajref_params(roadmap_name);   %设置trajref参数
    trajref_in = demo_generate_pretrajref(trajref_params_in,roadmap_name,Xstart,Ystart);         %生成trajref
    plot(trajref_in(1,:), trajref_in(2,:), 'k-', 'LineWidth', 1.5);
    hold on;
    axis equal

    otherwise
     disp('The roadmap does not exit!');
end  
    
% =========提前画出赛道==============
theta = linspace(0, 2*pi, 1000);
figure (1);
plot(trajref(1,:), trajref(2,:), 'b--', 'LineWidth', 0.5);
hold on;
% =========提前画出预设轨迹============== 

u_last=[0;0];%存储上一个时刻的u 
simulation_time=0;
veh_pose=x0;
trajectory(:,1)=veh_pose;
kk=1;
simulation_stop_time = (length(trajref)/10) / v_desire;


Final_index=length(trajref(1,:));
N=5;
u0 = zeros(2*N,1); %初始化控制变量
% % 启用并行池
% if isempty(gcp('nocreate'))
%     parpool;
% end
ulast=[4;0];
while(true)

%   计算车辆当前位置在期望路径上的投影点位姿
    target_ind= calc_target_index(veh_pose(1),veh_pose(2),trajref(1,:),trajref(2,:),n);
    if target_ind>=Final_index
        break;
    end
    ref_state=trajref(:,target_ind);
    current_state=veh_pose;
    curvature= trajref(5,target_ind);
   [mpc_v,mpc_delta,uu]=NMPC_controller(ref_state,current_state,dt,L,v_desire,curvature,N,v_min,v_max, delta_min,delta_max,ulast);
   
    
    optimal_controls = [mpc_v; mpc_delta];
    ulast=optimal_controls;
    u = uu;
    % 使用优化得到的控制信号更新状态
    veh_pose = NMPC_Bicycle_Discrete_Model_RK4(current_state, optimal_controls, dt, L);
    u_last=optimal_controls;%存储上一个时刻的u
    
    % Calculate and store predicted trajectory
    pred_x = zeros(1, N+1);
    pred_y = zeros(1, N+1);
    pred_x(1) = veh_pose(1);
    pred_y(1) = veh_pose(2);
    state = veh_pose;
    for k = 1:N
        v = u(2*k-1);
        delta = u(2*k);
        state = NMPC_Bicycle_Discrete_Model_RK4(state, [v;delta], dt, L);
        pred_x(k+1) = state(1);
        pred_y(k+1) = state(2);
    end
    
    %储存状态
    trajectory(:,kk) = veh_pose;
    traj_reference(:,kk) = ref_state(1:3);
    control_state(:,kk) = optimal_controls;
    curv(kk)=curvature;
    totaltime(kk)=simulation_time;
    simulation_time = simulation_time + dt;
    
    kk=kk+1;
    % 实时绘制轨迹
    figure (1)
    plot(veh_pose(1),veh_pose(2),'r*', 'MarkerSize', 2)
    hold on
    plot(pred_x, pred_y, 'g--', 'LineWidth', 2);
    hold on
end

    % =========提前画出赛道==============
    theta = linspace(0, 2*pi, 1000);
    figure (2);
    plot(trajref(1,:), trajref(2,:), 'b--', 'LineWidth', 1);
    hold on;
    
    
    
 
%     %=========提前画出赛道==============
    roadmap_name = 'loop_road_out';  %选择路网: straight_road circle_road loop_road
    Xstart=-2.5;
    Ystart=5;
    [trajref_params_out] =demo_set_trajref_params(roadmap_name);   %设置trajref参数
    trajref_out = demo_generate_pretrajref(trajref_params_out,roadmap_name,Xstart,Ystart);         %生成trajref
    plot(trajref_out(1,:), trajref_out(2,:), 'k-', 'LineWidth', 1.5);
    hold on;
    
    roadmap_name = 'loop_road_in';  %选择路网: straight_road circle_road loop_road
    Xstart=2.5;
    Ystart=-5;
    [trajref_params_in] =demo_set_trajref_params(roadmap_name);   %设置trajref参数
    trajref_in = demo_generate_pretrajref(trajref_params_in,roadmap_name,Xstart,Ystart);         %生成trajref
    plot(trajref_in(1,:), trajref_in(2,:), 'k-', 'LineWidth', 1.5);
    hold on;
%     axis equal

  
    % 实时小车绘制轨迹
    figure (2)
    plot(trajectory(1,1:kk-1) ,trajectory(2,1:kk-1) ,'k-.', 'LineWidth', 1.2)
    drawnow
    hold on
  % =========提前画出预设轨迹==============   
    % 实时绘制轨迹
    figure (13)
    plot(totaltime(1:kk-1),v_desire*ones(kk-1,1), 'LineWidth', 2);
    hold on;
    plot(totaltime(1:kk-1),control_state(1,1:kk-1), 'LineWidth', 2);

    
    
   

    figure (14)
    plot(totaltime(1:kk-1), atan(L .* curv(1:kk-1)), 'LineWidth', 2)
    hold on;
    plot(totaltime(1:kk-1),control_state(2,1:kk-1), 'LineWidth', 2);
    hold on;
    plot(totaltime(1:kk-1),pi/6*ones(kk-1,1), 'LineWidth', 2);
    hold on;
    plot(totaltime(1:kk-1),-pi/6*ones(kk-1,1), 'LineWidth', 2);
    hold on;

    
    %状态及期望  
    colors = {[0.635294117647059 0.0784313725490196 0.184313725490196], ...  % Red
    [17/255, 74/255, 15/255], ...  % Green
    [54/255, 54/255, 54/255], ...  % Black
    [125/255, 45/255, 185/255], ...% Purple
    [20/255, 43/255, 140/255], ... % blue
    [138/255, 104/255, 0/255], ... % brown
    [0.929, 0.694, 0.125], ...     % Yellow
    [0.301, 0.745, 0.933]};          % Light Blue
    lineStyles = {'-', '--', ':', '-.', '-', '--', ':'};
    figure (15);
    plot(totaltime(1:kk-1),traj_reference(1,1:kk-1),lineStyles{2}, 'Color', colors{2}, 'DisplayName', 'X_d', 'LineWidth', 2)
    hold on
    plot(totaltime(1:kk-1),trajectory(1,1:kk-1),lineStyles{1}, 'Color', colors{1}, 'DisplayName', 'X', 'LineWidth', 2);
    

    figure (16);
    plot(totaltime(1:kk-1),traj_reference(2,1:kk-1),lineStyles{3}, 'Color', colors{4}, 'DisplayName', 'Y_d', 'LineWidth', 2)
    hold on
    plot(totaltime(1:kk-1),trajectory(2,1:kk-1),lineStyles{4}, 'Color', colors{3}, 'DisplayName', 'Y', 'LineWidth', 2);
   
  
    figure (17);
    plot(totaltime(1:kk-1),traj_reference(3,1:kk-1),lineStyles{6}, 'Color', colors{6}, 'DisplayName', '$theta_d$', 'LineWidth', 2.5)
    hold on
    plot(totaltime(1:kk-1),trajectory(3,1:kk-1),lineStyles{5}, 'Color', colors{5}, 'DisplayName', '$theta$', 'LineWidth', 2.5);
 
  
    
    
    
    
n=0;
 for ii=1:(kk-1)  
     target_ind= calc_target_index(trajectory(1,ii),trajectory(2,ii),trajref(1,:),trajref(2,:),n);
     ref_x(ii)=trajref(1,target_ind);
     ref_y(ii)=trajref(2,target_ind);
     ref_yaw(ii)=trajref(3,target_ind);
     norm_x(ii)=norm(trajectory(1,ii)-ref_x(ii));
     norm_y(ii)=norm(trajectory(2,ii)-ref_y(ii));
     norm_exy(ii)=norm(trajectory(1:2,ii)-[ref_x(ii);ref_y(ii)]);
     norm_epsi(ii)=norm(trajectory(3,ii)-ref_yaw(ii));
     
     
     norm_vel(ii)=norm(control_state(1,ii)-v_desire);
     norm_delta(ii)=norm(control_state(2,ii)-atan(L .* curv(ii)));
     
 end
 
Max_errorexy = max(abs(norm_exy))
MAEexy = mean(abs(norm_exy))
RMSEexy = sqrt(mean(norm_exy))
  
Max_errorx = max(abs(norm_x))
MAEx = mean(abs(norm_x))
RMSEx = sqrt(mean(norm_x))
 
Max_errory = max(abs(norm_y))
MAEy = mean(abs(norm_y))
RMSEy = sqrt(mean(norm_y))
 
Max_errorepsi = max(abs(norm_epsi))
MAEepsi = mean(abs(norm_epsi))
RMSEepsi = sqrt(mean(norm_epsi))
 
Max_error_vel = max(abs(norm_vel))
MAE_vel = mean(abs(norm_vel))
RMSE_vel = sqrt(mean(norm_vel))

Max_error_delta = max(abs(norm_delta))
MAE_delta = mean(abs(norm_delta))
RMSE_delta = sqrt(mean(norm_delta))
 
%     figure (16)
%     plot(totaltime(1:kk-1),norm_exy, 'LineWidth', 2);
%     mean(norm_exy)
%     figure (16)
%     plot(totaltime(1:kk-1),norm_x, 'LineWidth', 2); hold on
%     plot(totaltime(1:kk-1),norm_y, 'LineWidth', 2);  hold on
%     plot(totaltime(1:kk-1),norm_epsi, 'LineWidth', 2);
    
    





















