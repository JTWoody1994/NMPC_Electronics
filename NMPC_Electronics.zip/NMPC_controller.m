
function [v,delta,u0] = NMPC_controller(ref_state,current_state,dt,L,v_d,curvature,N,v_min,v_max, delta_min,delta_max,u0)

delta_d=atan(L * curvature);%  期望前轮转角
%==============控制量的约束=====================
umin=[v_min;delta_min];
umax=[v_max; delta_max];
lb = repmat(umin, N, 1);
ub = repmat(umax, N, 1);
%==============控制量的约束=====================
Q = zeros(3, 3); Q(1, 1) = 1000; Q(2, 2) =1000; Q(3, 3) =1000; 
R = zeros(2, 2); R(1, 1) = 1000; R(2, 2) = 1000;  %权重参数可调
P=[current_state;ref_state(1:3)];

%==========粒子群算法==========
obj_fun = @(U) objectiveFunction(U', P, Q, R, N, dt, L,v_d,delta_d);
options = optimoptions('particleswarm', 'SwarmSize', 200, 'MaxIterations', 1000);
tic;
[u_now, ~] = particleswarm(obj_fun, 2*N, lb, ub, options);
toc
u0 = [u_now(3:end), u_now(end-1:end)]'; % Shift control inputs
%==========粒子群算法==========  

v = u_now(1);      
delta=  u_now(2);
end

